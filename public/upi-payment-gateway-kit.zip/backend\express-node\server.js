/**
 * Standalone Node.js & Express API Server for UPI Payment Gateway
 *
 * To run:
 *   npm install express cors
 *   node server.js
 */

const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 5000;
const DB_FILE = path.join(__dirname, "orders.json");

app.use(cors());
app.use(express.json());

// In-memory array initialized from orders.json if present
let orders = [];
try {
  if (fs.existsSync(DB_FILE)) {
    orders = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
  }
} catch (err) {
  orders = [];
}

function saveDb() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(orders.slice(0, 200), null, 2), "utf8");
  } catch (err) {
    console.error("Error saving orders.json:", err);
  }
}

function shortId() {
  return `ORD-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}

// 1. POST /api/orders — Customer creates checkout session
app.post("/api/orders", (req, res) => {
  const { items, total, customerName, upiApp } = req.body || {};
  if (!total) {
    return res.status(400).json({ error: "Missing required amount / total" });
  }

  const id = shortId();
  const newOrder = {
    id,
    customer_name: (customerName || "Customer").slice(0, 80),
    items: items || [],
    total: Number(total),
    upi_app: upiApp || "upi",
    status: "pending",
    utr: null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  orders.unshift(newOrder);
  saveDb();

  return res.status(201).json({ id, status: "pending" });
});

// 2. GET /api/orders — Customer polling OR Admin list
app.get("/api/orders", (req, res) => {
  const { id } = req.query;

  // Single order check (customer polling)
  if (id) {
    const found = orders.find((o) => o.id === id);
    if (found) {
      return res.json({
        id: found.id,
        status: found.status,
        utr: found.utr,
        created_at: found.created_at,
      });
    }
    return res.status(404).json({ error: "Order not found" });
  }

  // All orders (admin verification panel)
  return res.json(orders);
});

// 3. PATCH /api/orders — Customer submits manual UTR / Ref No.
app.patch("/api/orders", (req, res) => {
  const { id, utr } = req.body || {};
  if (!id || !utr) {
    return res.status(400).json({ error: "Missing id or utr" });
  }

  const found = orders.find((o) => o.id === id);
  if (found) {
    found.utr = String(utr).trim();
    found.updated_at = new Date().toISOString();
    saveDb();
    return res.json({ id, utr: found.utr });
  }
  return res.status(404).json({ error: "Order not found" });
});

// 4. PUT /api/orders — Admin confirms or rejects payment
app.put("/api/orders", (req, res) => {
  const { id, status } = req.body || {};
  if (!id || !["confirmed", "rejected"].includes(status)) {
    return res.status(400).json({ error: "Invalid status or missing id" });
  }

  const found = orders.find((o) => o.id === id);
  if (found) {
    found.status = status;
    found.updated_at = new Date().toISOString();
    saveDb();
    return res.json({ id, status });
  }
  return res.status(404).json({ error: "Order not found" });
});

app.listen(PORT, () => {
  console.log(`🚀 UPI Gateway Backend running on http://localhost:${PORT}`);
});
