/**
 * Vercel Serverless / Next.js API Route for UPI Orders
 * Place this in `api/orders.js` (for Vercel) or `pages/api/orders.js` (for Next.js)
 */

// In-memory fallback for local development or simple serverless caching
let memoryOrders = [];

function shortId() {
  return `ORD-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}

export default async function handler(req, res) {
  // CORS headers
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  try {
    // 1. POST /api/orders — Customer initiates payment session
    if (req.method === "POST") {
      const { items, total, customerName, upiApp } = req.body || {};
      if (!total) {
        return res.status(400).json({ error: "Missing required amount / total" });
      }

      const id = shortId();
      const newOrder = {
        id,
        customer_name: (customerName || "Customer").slice(0, 80),
        items: items || [],
        total: Number(total),
        upi_app: upiApp || "upi",
        status: "pending", // pending | confirmed | rejected
        utr: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // Store in memory (or save to Supabase/MongoDB/Postgres here)
      memoryOrders = [newOrder, ...memoryOrders.slice(0, 199)];

      return res.status(201).json({ id, status: "pending" });
    }

    // 2. GET /api/orders — Customer poll by ID OR Admin list all
    if (req.method === "GET") {
      const { id } = req.query || {};

      // A. Customer polling single order
      if (id) {
        const found = memoryOrders.find((o) => o.id === id);
        if (found) {
          return res.status(200).json({
            id: found.id,
            status: found.status,
            utr: found.utr,
            created_at: found.created_at,
          });
        }
        return res.status(404).json({ error: "Order session not found" });
      }

      // B. Admin listing all orders
      return res.status(200).json(memoryOrders);
    }

    // 3. PATCH /api/orders — Customer submits manual UTR / Ref No.
    if (req.method === "PATCH") {
      const { id, utr } = req.body || {};
      if (!id || !utr) {
        return res.status(400).json({ error: "Missing id or utr" });
      }

      const found = memoryOrders.find((o) => o.id === id);
      if (found) {
        found.utr = String(utr).trim();
        found.updated_at = new Date().toISOString();
        return res.status(200).json({ id, utr: found.utr });
      }
      return res.status(404).json({ error: "Order not found" });
    }

    // 4. PUT /api/orders — Admin confirms or declines payment
    if (req.method === "PUT") {
      const { id, status } = req.body || {};
      if (!id || !["confirmed", "rejected"].includes(status)) {
        return res.status(400).json({ error: "Invalid request payload" });
      }

      const found = memoryOrders.find((o) => o.id === id);
      if (found) {
        found.status = status;
        found.updated_at = new Date().toISOString();
        return res.status(200).json({ id, status });
      }
      return res.status(404).json({ error: "Order not found" });
    }

    return res.status(405).json({ error: "Method not allowed" });
  } catch (err) {
    return res.status(500).json({ error: err.message || "Internal server error" });
  }
}
