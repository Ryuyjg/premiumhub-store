import RestaurantOrdersAdmin from "./RestaurantOrdersAdmin.jsx";
export { RestaurantOrdersAdmin };
export { RestaurantOrdersAdmin as OrdersAdmin };
export default RestaurantOrdersAdmin;
