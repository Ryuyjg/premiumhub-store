import React, { useState, useEffect } from "react";

function formatCurrency(val) {
  return "₹" + Number(val || 0).toLocaleString("en-IN");
}

export function OrdersAdmin({
  apiBaseUrl = "",
  onPendingCountChange,
}) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("pending");
  const [actionMsg, setActionMsg] = useState("");

  const baseEndpoint = (apiBaseUrl ? apiBaseUrl.replace(/\/$/, "") : "") + "/api/orders";

  const loadOrders = async () => {
    try {
      const res = await fetch(baseEndpoint, { credentials: "include", cache: "no-store" });
      if (!res.ok) return;
      const data = await res.json();
      if (Array.isArray(data)) {
        setOrders(data);
        const pCount = data.filter((o) => o.status === "pending").length;
        if (onPendingCountChange) onPendingCountChange(pCount);
      }
    } catch (err) {
      console.error("Failed to load orders:", err);
    } finally {
      setLoading(false);
    }
  };

  // Load initially + auto-refresh every 5 seconds so admin sees incoming payments in real time
  useEffect(() => {
    loadOrders();
    const timer = setInterval(loadOrders, 5000);
    return () => clearInterval(timer);
  }, [baseEndpoint]);

  const handleAction = async (id, status) => {
    try {
      const res = await fetch(baseEndpoint, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ id, status }),
      });
      if (res.ok) {
        setActionMsg(
          status === "confirmed"
            ? "✅ Payment confirmed! Customer's screen updated with confetti & chime."
            : "❌ Order marked as declined."
        );
        setTimeout(() => setActionMsg(""), 4000);
        loadOrders();
      } else {
        setActionMsg("Failed to update order status.");
      }
    } catch {
      setActionMsg("Failed to update order status. Please retry.");
    }
  };

  const pendingList = orders.filter((o) => o.status === "pending");
  const shownOrders = orders.filter((o) => filter === "all" || o.status === filter);

  return (
    <section className="admin-editor" style={{ maxWidth: 900, margin: "0 auto", padding: 16 }}>
      <div className="section-head" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12, marginBottom: 16 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: "1.35rem" }}>Payment Verification Dashboard</h2>
          <small style={{ color: "#64748b" }}>Live UPI transactions &bull; Confirm payments to release orders</small>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          <button
            type="button"
            className={filter === "pending" ? "order-filter-btn active" : "order-filter-btn ghost"}
            onClick={() => setFilter("pending")}
          >
            Pending ({pendingList.length})
          </button>
          <button
            type="button"
            className={filter === "confirmed" ? "order-filter-btn active" : "order-filter-btn ghost"}
            onClick={() => setFilter("confirmed")}
          >
            Confirmed
          </button>
          <button
            type="button"
            className={filter === "rejected" ? "order-filter-btn active" : "order-filter-btn ghost"}
            onClick={() => setFilter("rejected")}
          >
            Rejected
          </button>
          <button
            type="button"
            className={filter === "all" ? "order-filter-btn active" : "order-filter-btn ghost"}
            onClick={() => setFilter("all")}
          >
            All ({orders.length})
          </button>
          <button type="button" className="order-filter-btn ghost" onClick={loadOrders}>
            🔄 Refresh
          </button>
        </div>
      </div>

      {actionMsg && (
        <div style={{ padding: "10px 14px", background: "#f0fdf4", color: "#166534", borderRadius: 8, marginBottom: 14, fontWeight: 600 }}>
          {actionMsg}
        </div>
      )}

      {loading && orders.length === 0 ? (
        <p style={{ padding: 24, textAlign: "center", color: "#64748b" }}>Checking incoming orders...</p>
      ) : shownOrders.length === 0 ? (
        <div style={{ padding: 40, textAlign: "center", background: "#f8fafc", borderRadius: 16, border: "1.5px dashed #cbd5e1" }}>
          <p style={{ margin: 0, fontSize: "1rem", color: "#64748b", fontWeight: 600 }}>
            No {filter} payment sessions found.
          </p>
          <small style={{ color: "#94a3b8" }}>When a customer opens UPI checkout, their session appears here in real time.</small>
        </div>
      ) : (
        <div className="orders-list" style={{ display: "grid", gap: 12 }}>
          {shownOrders.map((order) => {
            const items = (() => {
              try {
                return typeof order.items === "string" ? JSON.parse(order.items) : order.items || [];
              } catch {
                return [];
              }
            })();

            const createdTime = new Date(order.created_at);
            const minutesAgo = Math.round((Date.now() - createdTime.getTime()) / 60000);
            const timeFormatted = isNaN(createdTime.getTime())
              ? "Just now"
              : minutesAgo < 1
              ? "Just now"
              : minutesAgo < 60
              ? `${minutesAgo}m ago`
              : `${Math.round(minutesAgo / 60)}h ago`;

            return (
              <div key={order.id} className={`order-card order-${order.status}`}>
                <div className="order-card-top">
                  <div>
                    <strong className="order-id">{order.id}</strong>
                    <span className="order-meta">
                      Method: <strong>{order.upi_app || "UPI"}</strong> &middot; {timeFormatted}
                      {order.utr && (
                        <span style={{ marginLeft: 8, color: "#2563eb", fontWeight: 700 }}>
                          &bull; UTR: {order.utr}
                        </span>
                      )}
                    </span>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <strong className="order-total">{formatCurrency(order.total)}</strong>
                    <span className={`order-status-badge order-status-${order.status}`}>
                      {order.status}
                    </span>
                  </div>
                </div>

                <div className="order-items">
                  {items.map((item, idx) => (
                    <span key={idx} className="order-item-pill">
                      {item.name} &middot; {item.variation} {item.qty > 1 ? `x${item.qty}` : ""} ({formatCurrency(item.price)})
                    </span>
                  ))}
                </div>

                {order.status === "pending" && (
                  <div className="order-actions">
                    <button
                      type="button"
                      className="order-confirm-btn"
                      onClick={() => handleAction(order.id, "confirmed")}
                    >
                      ✅ Confirm Payment
                    </button>
                    <button
                      type="button"
                      className="order-reject-btn"
                      onClick={() => handleAction(order.id, "rejected")}
                    >
                      ❌ Decline
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
export default OrdersAdmin;
