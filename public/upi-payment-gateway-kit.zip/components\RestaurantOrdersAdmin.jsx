import React, { useState, useEffect, useRef } from "react";

function formatCurrency(val) {
  return "₹" + Number(val || 0).toLocaleString("en-IN");
}

export function RestaurantOrdersAdmin({
  apiBaseUrl = "http://localhost:5000",
  onNewOrder,
}) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("pending");
  const [actionMsg, setActionMsg] = useState("");
  const prevCountRef = useRef(0);

  const baseEndpoint = (apiBaseUrl ? apiBaseUrl.replace(/\/$/, "") : "") + "/api/orders";

  const playKitchenAlert = () => {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.4);
    } catch {}
  };

  const loadOrders = async () => {
    try {
      const res = await fetch(baseEndpoint, { cache: "no-store" });
      if (!res.ok) return;
      const data = await res.json();
      if (Array.isArray(data)) {
        // Sound alert if new pending order arrived
        const pendingCount = data.filter((o) => o.status === "pending").length;
        if (pendingCount > prevCountRef.current && prevCountRef.current !== 0) {
          playKitchenAlert();
          if (onNewOrder) onNewOrder(data[0]);
        }
        prevCountRef.current = pendingCount;
        setOrders(data);
      }
    } catch (err) {
      console.error("Failed to load restaurant orders:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
    const interval = setInterval(loadOrders, 4000);
    return () => clearInterval(interval);
  }, [baseEndpoint]);

  const updateStatus = async (id, status) => {
    try {
      const res = await fetch(baseEndpoint, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status }),
      });
      if (res.ok) {
        setActionMsg(`✅ Order ${id} updated to "${status}".`);
        setTimeout(() => setActionMsg(""), 3500);
        loadOrders();
      } else {
        setActionMsg("Failed to update status.");
      }
    } catch {
      setActionMsg("Network error updating status.");
    }
  };

  const pendingOrders = orders.filter((o) => o.status === "pending");
  const shownOrders = orders.filter((o) => filter === "all" || o.status === filter);

  return (
    <div style={{ maxWidth: 960, margin: "0 auto", padding: 16 }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12, marginBottom: 16 }}>
        <div>
          <h2 style={{ margin: "0 0 4px", fontSize: "1.4rem", color: "#0f172a" }}>
            🍲 Kitchen & Payment Live Dashboard
          </h2>
          <small style={{ color: "#64748b" }}>
            Auto-refreshes every 4s &bull; Confirm payments to release orders to kitchen
          </small>
        </div>

        {/* Filter Pills */}
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          <button
            type="button"
            className={filter === "pending" ? "order-filter-btn active" : "order-filter-btn ghost"}
            onClick={() => setFilter("pending")}
          >
            Pending Payments ({pendingOrders.length})
          </button>
          <button
            type="button"
            className={filter === "preparing" ? "order-filter-btn active" : "order-filter-btn ghost"}
            onClick={() => setFilter("preparing")}
          >
            Preparing 🍳
          </button>
          <button
            type="button"
            className={filter === "out_for_delivery" ? "order-filter-btn active" : "order-filter-btn ghost"}
            onClick={() => setFilter("out_for_delivery")}
          >
            Out for Delivery 🛵
          </button>
          <button
            type="button"
            className={filter === "delivered" ? "order-filter-btn active" : "order-filter-btn ghost"}
            onClick={() => setFilter("delivered")}
          >
            Delivered ✅
          </button>
          <button
            type="button"
            className={filter === "all" ? "order-filter-btn active" : "order-filter-btn ghost"}
            onClick={() => setFilter("all")}
          >
            All ({orders.length})
          </button>
          <button type="button" className="order-filter-btn ghost" onClick={loadOrders}>
            🔄 Refresh
          </button>
        </div>
      </div>

      {actionMsg && (
        <div style={{ padding: "10px 14px", background: "#f0fdf4", color: "#166534", borderRadius: 8, marginBottom: 14, fontWeight: 600 }}>
          {actionMsg}
        </div>
      )}

      {loading && orders.length === 0 ? (
        <p style={{ textAlign: "center", padding: 32, color: "#64748b" }}>Checking incoming food orders...</p>
      ) : shownOrders.length === 0 ? (
        <div style={{ padding: 40, textAlign: "center", background: "#f8fafc", borderRadius: 16, border: "1.5px dashed #cbd5e1" }}>
          <p style={{ margin: 0, fontSize: "1rem", color: "#64748b", fontWeight: 600 }}>
            No {filter} food orders at the moment.
          </p>
          <small style={{ color: "#94a3b8" }}>When a customer chooses UPI payment, their order shows here in real time.</small>
        </div>
      ) : (
        <div style={{ display: "grid", gap: 14 }}>
          {shownOrders.map((order) => {
            const items = Array.isArray(order.items) ? order.items : [];
            const isPending = order.status === "pending";

            return (
              <div
                key={order.id}
                style={{
                  background: isPending ? "#fffbeb" : "#ffffff",
                  border: isPending ? "2px solid #f59e0b" : "1px solid #e2e8f0",
                  borderRadius: 14,
                  padding: 16,
                  boxShadow: "0 2px 8px rgba(0,0,0,0.03)",
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 10 }}>
                  <div>
                    <span style={{ fontSize: "1.1rem", fontWeight: 800, color: "#0f172a" }}>{order.id}</span>
                    <span style={{ marginLeft: 10, fontSize: "0.85rem", color: "#64748b" }}>
                      {new Date(order.created_at).toLocaleTimeString("en-IN", { timeStyle: "short" })}
                    </span>
                    {order.utr && (
                      <div style={{ marginTop: 4, display: "inline-block", background: "#dbeafe", color: "#1e40af", padding: "2px 8px", borderRadius: 6, fontSize: "0.8rem", fontWeight: 700 }}>
                        UTR: {order.utr}
                      </div>
                    )}
                  </div>

                  <div style={{ textAlign: "right" }}>
                    <strong style={{ fontSize: "1.25rem", color: "#0f172a", display: "block" }}>
                      {formatCurrency(order.total)}
                    </strong>
                    <span
                      style={{
                        display: "inline-block",
                        padding: "3px 8px",
                        borderRadius: 6,
                        fontSize: "0.75rem",
                        fontWeight: 800,
                        textTransform: "uppercase",
                        background:
                          order.status === "pending"
                            ? "#fef3c7"
                            : order.status === "preparing"
                            ? "#e0e7ff"
                            : order.status === "out_for_delivery"
                            ? "#fed7aa"
                            : order.status === "delivered"
                            ? "#dcfce7"
                            : "#fee2e2",
                        color:
                          order.status === "pending"
                            ? "#92400e"
                            : order.status === "preparing"
                            ? "#3730a3"
                            : order.status === "out_for_delivery"
                            ? "#9a3412"
                            : order.status === "delivered"
                            ? "#166534"
                            : "#991b1b",
                      }}
                    >
                      {order.status.replace(/_/g, " ")}
                    </span>
                  </div>
                </div>

                {/* Customer Details */}
                <div style={{ margin: "10px 0", padding: "8px 12px", background: "#f8fafc", borderRadius: 8, fontSize: "0.86rem" }}>
                  <strong>{order.customer_name}</strong> {order.customer_phone ? `(${order.customer_phone})` : ""}
                  {order.delivery_address && (
                    <div style={{ color: "#475569", marginTop: 2 }}>📍 {order.delivery_address}</div>
                  )}
                  {order.notes && (
                    <div style={{ color: "#ea580c", fontSize: "0.8rem", marginTop: 2 }}>📝 Note: {order.notes}</div>
                  )}
                </div>

                {/* Food Items */}
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6, margin: "10px 0" }}>
                  {items.map((it, idx) => (
                    <span
                      key={idx}
                      style={{
                        background: "#f1f5f9",
                        padding: "4px 10px",
                        borderRadius: 6,
                        fontSize: "0.82rem",
                        fontWeight: 600,
                        color: "#334155",
                      }}
                    >
                      {it.name} &times; {it.qty || it.quantity || 1} ({formatCurrency(it.price)})
                    </span>
                  ))}
                </div>

                {/* Action Buttons for Kitchen Manager */}
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12, borderTop: "1px solid #f1f5f9", paddingTop: 10 }}>
                  {isPending && (
                    <>
                      <button
                        type="button"
                        onClick={() => updateStatus(order.id, "confirmed")}
                        style={{ padding: "8px 16px", background: "#16a34a", color: "#fff", border: 0, borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.85rem" }}
                      >
                        ✅ Confirm Payment & Accept Order
                      </button>
                      <button
                        type="button"
                        onClick={() => updateStatus(order.id, "rejected")}
                        style={{ padding: "8px 12px", background: "#fee2e2", color: "#dc2626", border: 0, borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.85rem" }}
                      >
                        ❌ Decline
                      </button>
                    </>
                  )}

                  {order.status === "confirmed" && (
                    <button
                      type="button"
                      onClick={() => updateStatus(order.id, "preparing")}
                      style={{ padding: "8px 14px", background: "#4f46e5", color: "#fff", border: 0, borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.85rem" }}
                    >
                      🍳 Move to Kitchen Preparing
                    </button>
                  )}

                  {order.status === "preparing" && (
                    <button
                      type="button"
                      onClick={() => updateStatus(order.id, "out_for_delivery")}
                      style={{ padding: "8px 14px", background: "#ea580c", color: "#fff", border: 0, borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.85rem" }}
                    >
                      🛵 Handed to Delivery Partner
                    </button>
                  )}

                  {order.status === "out_for_delivery" && (
                    <button
                      type="button"
                      onClick={() => updateStatus(order.id, "delivered")}
                      style={{ padding: "8px 14px", background: "#16a34a", color: "#fff", border: 0, borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: "0.85rem" }}
                    >
                      ✅ Mark Delivered
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default RestaurantOrdersAdmin;
