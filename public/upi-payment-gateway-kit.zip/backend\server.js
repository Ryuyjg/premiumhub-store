/**
 * Standalone Node.js & Express Backend for Food Delivery UPI Payments & Order Verification
 *
 * Requirements:
 *   npm install express cors
 * Run:
 *   node server.js
 *
 * Runs on http://localhost:5000 (or any PORT environment variable)
 * No Vercel or external database required! Stores orders in local `orders.json`.
 */

const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 5000;
const DB_FILE = path.join(__dirname, "orders.json");

// Enable CORS so your React / Vite / Mobile frontend can connect freely
app.use(cors());
app.use(express.json());

// In-memory orders loaded from orders.json
let orders = [];
try {
  if (fs.existsSync(DB_FILE)) {
    orders = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
  }
} catch (err) {
  orders = [];
}

function saveDb() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(orders.slice(0, 300), null, 2), "utf8");
  } catch (err) {
    console.error("Error saving orders.json:", err);
  }
}

function generateOrderId() {
  const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, "");
  const randomSuffix = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `FD-${dateStr}-${randomSuffix}`;
}

// ============================================================================
// 1. POST /api/orders — Customer creates a food delivery order & UPI session
// ============================================================================
app.post("/api/orders", (req, res) => {
  const {
    customerName,
    customerPhone,
    deliveryAddress,
    notes,
    items,
    subtotal,
    deliveryFee,
    total,
    upiApp,
  } = req.body || {};

  if (!total) {
    return res.status(400).json({ error: "Missing required order total amount" });
  }

  const id = generateOrderId();
  const newOrder = {
    id,
    customer_name: (customerName || "Customer").slice(0, 80),
    customer_phone: (customerPhone || "").slice(0, 20),
    delivery_address: (deliveryAddress || "").slice(0, 250),
    notes: (notes || "").slice(0, 200),
    items: Array.isArray(items) ? items : [],
    subtotal: Number(subtotal || total),
    delivery_fee: Number(deliveryFee || 0),
    total: Number(total),
    upi_app: upiApp || "upi",
    status: "pending", // pending -> confirmed (kitchen preparing) -> out_for_delivery -> delivered | rejected
    utr: null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  orders.unshift(newOrder);
  saveDb();

  console.log(`[FOOD ORDER CREATED] ${id} - ${newOrder.customer_name} - ₹${newOrder.total}`);
  return res.status(201).json({ id, status: "pending" });
});

// ============================================================================
// 2. GET /api/orders — Customer Polling OR Restaurant Kitchen Admin
// ============================================================================
app.get("/api/orders", (req, res) => {
  const { id } = req.query;

  // A. Customer polling single order status
  if (id) {
    const found = orders.find((o) => o.id === id);
    if (found) {
      return res.json({
        id: found.id,
        status: found.status,
        customer_name: found.customer_name,
        customer_phone: found.customer_phone,
        delivery_address: found.delivery_address,
        items: found.items,
        total: found.total,
        utr: found.utr,
        created_at: found.created_at,
        updated_at: found.updated_at,
      });
    }
    return res.status(404).json({ error: "Order not found" });
  }

  // B. Restaurant Admin listing all active food orders
  return res.json(orders);
});

// ============================================================================
// 3. PATCH /api/orders — Customer submits manual 12-digit UPI UTR / Ref No.
// ============================================================================
app.patch("/api/orders", (req, res) => {
  const { id, utr } = req.body || {};
  if (!id || !utr) {
    return res.status(400).json({ error: "Missing id or utr" });
  }

  const found = orders.find((o) => o.id === id);
  if (found) {
    found.utr = String(utr).trim();
    found.updated_at = new Date().toISOString();
    saveDb();
    console.log(`[UTR SUBMITTED] Order ${id} -> UTR: ${found.utr}`);
    return res.json({ id, utr: found.utr });
  }
  return res.status(404).json({ error: "Order not found" });
});

// ============================================================================
// 4. PUT /api/orders — Restaurant Admin confirms payment or updates food status
// ============================================================================
app.put("/api/orders", (req, res) => {
  const { id, status } = req.body || {};
  const allowed = ["confirmed", "preparing", "out_for_delivery", "delivered", "rejected"];

  if (!id || !allowed.includes(status)) {
    return res.status(400).json({ error: `Invalid status. Must be one of: ${allowed.join(", ")}` });
  }

  const found = orders.find((o) => o.id === id);
  if (found) {
    found.status = status;
    found.updated_at = new Date().toISOString();
    saveDb();
    console.log(`[ORDER UPDATED] Order ${id} -> Status: ${status}`);
    return res.json({ id, status });
  }
  return res.status(404).json({ error: "Order not found" });
});

app.listen(PORT, () => {
  console.log(`🍲 Food Delivery UPI Backend running on http://localhost:${PORT}`);
});
