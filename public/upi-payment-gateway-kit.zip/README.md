# ⚡ UPI Payment Gateway Kit (Plug & Play)

A complete, standalone UPI Payment Gateway component for **React**, **Next.js**, or **Vite** web applications.

Features automatic dynamic QR generation, instant 1-tap app payment buttons (PhonePe, Google Pay, Paytm, and BHIM/UPI), automatic background polling, real-time manual admin payment verification, Web Audio celebration chime, confetti explosion, and printable digital warranty receipt.

---

## 🌟 Features

- 📱 **1-Tap App Deep Linking**: Native deep linking for **PhonePe**, **Google Pay (GPay)**, **Paytm**, and **Any UPI app** (`intent://` on Android and custom schemes on iOS).
- 📷 **Dynamic QR Generation**: Crisp high-contrast QR code generated in real time with exact merchant VPA and dynamic transaction amount.
- ⏱️ **Active Countdown Session Timer**: 8-minute countdown timer with automatic expiry handling.
- 🟢 **Live Status Pulse**: Dynamic "Waiting for payment..." radar pulse indicator.
- 📋 **One-Click UPI ID Copy**: Tap to copy UPI ID with instant visual feedback.
- 🛡️ **Real-Time Manual Verification**: Admin dashboard auto-refreshes every 5s. Clicking **"✅ Confirm Payment"** instantly updates the customer's screen in under 3 seconds!
- ✍️ **Optional Customer UTR Submission**: Customers can optionally submit their 12-digit UPI Reference / UTR number to speed up verification.
- 🔊 **Zero-Dependency Success Chime**: Built-in 4-tone ascending GPay-style payment chime generated using browser `AudioContext` (no external MP3 files needed).
- 🎉 **Celebratory Confetti**: Colorful multi-cannon confetti blast upon payment confirmation.
- 📄 **Official Warranty Receipt Modal**: Customer can view, print, or save as PDF their official warranty certificate.
- 💬 **1-Click WhatsApp Order Claim**: Direct WhatsApp redirect pre-filled with order ID, verified amount, and purchased items.

---

## 📁 Package Structure

```
upi-payment-gateway-kit/
├── components/
│   ├── UpiPaymentCheckout.jsx         # Main customer checkout modal / view
│   ├── OrdersAdmin.jsx                # Admin live manual verification dashboard
│   ├── OrderCompletedClaimScreen.jsx  # Confirmed screen with WhatsApp & PDF receipt
│   ├── celebration.js                 # Web Audio chime + confetti burst
│   └── UpiLogos.jsx                   # SVG vector icons (PhonePe, GPay, Paytm, UPI)
├── styles/
│   └── upi.css                        # Complete responsive stylesheet
├── backend/
│   ├── vercel-serverless/
│   │   └── api/orders.js              # Vercel / Next.js Serverless API Route
│   └── express-node/
│       └── server.js                  # Standalone Express.js server
├── demo/
│   └── DemoApp.jsx                    # Interactive side-by-side demo
├── package.json
└── README.md
```

---

## 🚀 Quick Setup (5 Minutes)

### Step 1: Install Peer Dependencies
In your React, Next.js, or Vite project, install the two lightweight helper packages:

```bash
npm install qrcode canvas-confetti
```

### Step 2: Copy Files
Copy the `components/` and `styles/` directories into your project `src/` folder:
- `src/components/UpiPaymentCheckout.jsx`
- `src/components/OrdersAdmin.jsx`
- `src/components/OrderCompletedClaimScreen.jsx`
- `src/components/celebration.js`
- `src/components/UpiLogos.jsx`
- `src/styles/upi.css`

Import the CSS in your root file (e.g. `main.jsx`, `App.jsx`, or `_app.js`):
```javascript
import "./styles/upi.css";
```

---

## 💻 Frontend Usage

### 1. Customer Checkout Component (`UpiPaymentCheckout`)

Embed `<UpiPaymentCheckout />` anywhere in your cart, product modal, or pricing page:

```jsx
import React, { useState } from "react";
import UpiPaymentCheckout from "./components/UpiPaymentCheckout";
import "./styles/upi.css";

export default function CheckoutPage() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div>
      <button onClick={() => setIsOpen(true)}>Pay ₹199 with UPI</button>

      {isOpen && (
        <UpiPaymentCheckout
          amount={199}
          items={[
            { name: "Netflix Premium", variation: "1 Month 4K", qty: 1, price: 199 }
          ]}
          customerName="John Doe"
          upiId="yourname@upi"              // 👈 Replace with your UPI ID / VPA
          merchantName="Your Store Name"    // 👈 Your Brand Name
          supportPhone="+919876543210"      // 👈 Your WhatsApp support number
          apiBaseUrl=""                     // 👈 Leave empty if using relative /api/orders
          onSuccess={(order) => {
            console.log("Payment Confirmed!", order);
          }}
          onCancel={() => setIsOpen(false)}
        />
      )}
    </div>
  );
}
```

#### Component Props:

| Prop | Type | Default | Description |
|---|---|---|---|
| `amount` | `number` | `0` | Total transaction amount in INR (e.g. `199`). |
| `items` | `Array` | `[]` | Array of `{ name, variation, qty, price }`. |
| `customerName`| `string` | `"Customer"` | Customer's name. |
| `upiId` | `string` | `"anshidop@upi"` | Your Merchant UPI VPA address. |
| `merchantName`| `string` | `"Premium Hub"` | Display name shown inside UPI apps. |
| `supportPhone`| `string` | `"+917012958322"`| WhatsApp phone number for customer claims. |
| `apiBaseUrl` | `string` | `""` | Backend API base URL (e.g. `"http://localhost:5000"` or `""`). |
| `onSuccess` | `function` | `undefined` | Callback `(order) => {}` fired when confirmed. |
| `onCancel` | `function` | `undefined` | Callback `() => {}` fired when user cancels. |

---

### 2. Admin Verification Dashboard (`OrdersAdmin`)

Place `<OrdersAdmin />` on your private `/admin` dashboard:

```jsx
import React from "react";
import OrdersAdmin from "./components/OrdersAdmin";
import "./styles/upi.css";

export default function AdminDashboard() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Store Admin</h1>
      <OrdersAdmin apiBaseUrl="" />
    </div>
  );
}
```

**How Manual Verification Works**:
1. When a customer initiates UPI checkout, a pending session (e.g. `ORD-MK8X-19A`) appears immediately in the Admin panel.
2. The admin receives the payment on their UPI app (PhonePe / GPay / Paytm / Bank SMS).
3. The admin clicks **"✅ Confirm Payment"**.
4. The customer's screen polls every 3 seconds, detects the confirmation, plays the GPay chime, shoots confetti, and displays the **Verified Paid** claim screen and printable warranty receipt!

---

## 🛠️ Backend Setup Options

### Option A: Vercel / Next.js Serverless Route
Copy `backend/vercel-serverless/api/orders.js`:
- For **Vercel**: Place in `api/orders.js`.
- For **Next.js (Pages Router)**: Place in `pages/api/orders.js`.
- For **Next.js (App Router)**: Adapt to `app/api/orders/route.js`.

### Option B: Standalone Express.js Node Server
If you are running an Express.js backend:
```bash
cd backend/express-node
npm install express cors
node server.js
```
The server starts on `http://localhost:5000` with automatic persistence in `orders.json`. Set `apiBaseUrl="http://localhost:5000"` in your frontend component!

---

## 📲 How UPI Mobile Deep Linking Works

- **Android**:
  Uses Android Chrome Intent URIs to guarantee the exact target app opens without app-picker ambiguity:
  ```
  intent://pay?pa=...&pn=...&am=...&cu=INR#Intent;scheme=upi;package=com.phonepe.app;end
  ```
- **iOS (iPhone/iPad)**:
  Uses registered custom URL schemes:
  - PhonePe: `phonepe://pay?...`
  - Google Pay: `gpay://upi/pay?...`
  - Paytm: `paytmmp://pay?...`
  - Generic UPI: `upi://pay?...`

---

## 📄 License
MIT License. Free to use in personal and commercial projects.
