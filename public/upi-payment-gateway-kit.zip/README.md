# 🍲 Food Delivery UPI Payment Gateway Kit (Plug & Play)

Complete, standalone UPI payment gateway & manual kitchen verification system designed specifically for **Food Delivery Apps** and restaurant ordering systems.

**Zero Vercel dependencies**. Powered by standard **Node.js + Express.js** backend with automatic local file persistence (`orders.json`) or pluggable into any database (MongoDB, MySQL, PostgreSQL, SQLite).

---

## 🌟 Features Tailored for Food Delivery

1. 📷 **Dynamic UPI QR Code**: Automatically generated with exact bill amount and restaurant VPA (`upi://pay?pa=...&pn=...&am=...`).
2. 📱 **1-Tap UPI Apps**: Deep-links directly into **PhonePe**, **Google Pay**, **Paytm**, and **Any UPI App** on mobile without app-picker errors.
3. 🛵 **Delivery Details Passed Automatically**: Customer name, phone, delivery address, and notes attached to every transaction session.
4. 👨‍🍳 **Kitchen Live Dashboard (`<RestaurantOrdersAdmin />`)**:
   - Auto-refreshes every 4 seconds.
   - Audio bell alert when a new order arrives.
   - Checks bank/UPI app and clicks **"✅ Confirm Payment & Accept Order"** with 1 tap.
   - Can update status: `Kitchen Preparing 🍳` &rarr; `Handed to Delivery Boy 🛵` &rarr; `Delivered ✅`.
5. ⚡ **Instant Customer Reactive Screen (`<FoodOrderSuccessScreen />`)**:
   - When the kitchen accepts the payment, customer's phone immediately triggers:
     - Ascending 4-note payment chime (Web Audio API, no MP3 files).
     - Celebratory multi-cannon confetti burst.
     - Live food delivery progress timeline (`Paid` &rarr; `Kitchen Preparing` &rarr; `On the Way`).
6. 🧾 **Printable Food Bill / Tax Invoice Modal**: Customer can view, print, or save as PDF an itemized restaurant cash memo.
7. 💬 **WhatsApp Kitchen Order Connect**: Direct WhatsApp message pre-filled with order ID, items, delivery address, and verified total.

---

## 📁 Package Contents

```
upi-payment-gateway-kit/
├── backend/
│   └── server.js                      # Pure Node.js & Express API server (No Vercel!)
├── components/
│   ├── FoodUpiCheckout.jsx            # Customer checkout modal / screen
│   ├── FoodOrderSuccessScreen.jsx     # Live food delivery tracking & bill receipt
│   ├── RestaurantOrdersAdmin.jsx      # Kitchen admin manual payment verification panel
│   ├── UpiLogos.jsx                   # Vector SVG icons (PhonePe, GPay, Paytm, UPI)
│   ├── celebration.js                 # Web Audio chime + confetti burst
│   ├── UpiPaymentCheckout.jsx         # Alias / re-export
│   └── OrdersAdmin.jsx                # Alias / re-export
├── styles/
│   └── upi.css                        # Complete responsive food ordering stylesheet
├── demo/
│   └── DemoApp.jsx                    # Interactive Customer + Kitchen test app
├── package.json
└── README.md
```

---

## 🚀 How to Run Backend (2 Minutes)

Open terminal in the `backend/` directory:

```bash
cd backend
npm install express cors
node server.js
```

Your API server is running at **`http://localhost:5000`**!
Orders are stored in `orders.json` automatically.

---

## 💻 How to Use in Your Frontend (React / Vite / Next.js)

### Step 1: Install Peer Dependencies
```bash
npm install qrcode canvas-confetti
```

### Step 2: Copy Files
Copy `components/` and `styles/upi.css` into your food app's `src/` folder.
Import the stylesheet:
```javascript
import "./styles/upi.css";
```

### Step 3: Embed Customer Checkout
```jsx
import React, { useState } from "react";
import FoodUpiCheckout from "./components/FoodUpiCheckout";
import "./styles/upi.css";

export default function CartPage() {
  const [openPayment, setOpenPayment] = useState(false);

  const cartItems = [
    { name: "Chicken Dum Biryani", qty: 2, price: 340 },
    { name: "Butter Naan", qty: 3, price: 120 }
  ];

  return (
    <div>
      <button onClick={() => setOpenPayment(true)}>
        Place Order & Pay ₹500 via UPI
      </button>

      {openPayment && (
        <FoodUpiCheckout
          amount={500}
          subtotal={460}
          deliveryFee={40}
          items={cartItems}
          customerName="Rahul Sharma"
          customerPhone="+91 9876543210"
          deliveryAddress="Flat 402, Green Valley Apartments, MG Road"
          deliveryNotes="Ring bell, leave at door"
          upiId="anshidop@upi"                   // 👈 Your Merchant UPI ID
          restaurantName="Royal Spice Kitchen"   // 👈 Your Restaurant Name
          restaurantPhone="+917012958322"       // 👈 Restaurant Phone / WhatsApp
          apiBaseUrl="http://localhost:5000"    // 👈 Your Node.js backend URL
          onCancel={() => setOpenPayment(false)}
        />
      )}
    </div>
  );
}
```

---

### Step 4: Embed Kitchen / Admin Panel
Place `<RestaurantOrdersAdmin />` on your restaurant manager dashboard:

```jsx
import React from "react";
import RestaurantOrdersAdmin from "./components/RestaurantOrdersAdmin";
import "./styles/upi.css";

export default function KitchenDashboard() {
  return (
    <div style={{ padding: 20 }}>
      <RestaurantOrdersAdmin apiBaseUrl="http://localhost:5000" />
    </div>
  );
}
```

When a customer initiates an order, the kitchen manager hears an audio alert ping and sees the order in **Pending Payments**. When the manager checks their PhonePe/GPay and taps **"✅ Confirm Payment & Accept Order"**, the customer's phone instantly celebrates with confetti, sound, and live food tracking!

---

## 📄 License
MIT License. Free to use in your food delivery apps.
