import React, { useState, useEffect } from "react";
import { PhonePeLogo, GPayLogo, PaytmLogo, UpiLogo } from "./UpiLogos.jsx";
import { OrderCompletedClaimScreen } from "./OrderCompletedClaimScreen.jsx";
import { playSuccessChime, triggerPaymentConfetti } from "./celebration.js";

// Optional dynamic import or standard import for QRCode
let QRCodeLib = null;
try {
  import("qrcode").then((mod) => {
    QRCodeLib = mod.default || mod;
  }).catch(() => {});
} catch {}

function formatCurrency(val) {
  return "₹" + Number(val || 0).toLocaleString("en-IN");
}

/**
 * Builds native UPI deep link for Android and iOS devices
 */
export function getUpiLink(app, amount, upiId, merchantName) {
  const isAndroid = typeof navigator !== "undefined" && /Android/i.test(navigator.userAgent);
  const isIOS = typeof navigator !== "undefined" && /iPhone|iPad|iPod/i.test(navigator.userAgent);
  const amt = Number(amount).toFixed(2);
  const base = `pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(merchantName)}&am=${encodeURIComponent(amt)}&cu=INR&tn=Order`;

  if (isAndroid) {
    if (app === "phonepe") {
      return `intent://pay?${base}#Intent;scheme=upi;package=com.phonepe.app;end`;
    }
    if (app === "gpay") {
      return `intent://pay?${base}#Intent;scheme=upi;package=com.google.android.apps.nbu.paisa.user;end`;
    }
    if (app === "paytm") {
      return `intent://pay?${base}#Intent;scheme=upi;package=net.one97.paytm;end`;
    }
    return `upi://pay?${base}`;
  }

  if (isIOS) {
    if (app === "phonepe") return `phonepe://pay?${base}`;
    if (app === "gpay") return `gpay://upi/pay?${base}`;
    if (app === "paytm") return `paytmmp://pay?${base}`;
    return `upi://pay?${base}`;
  }

  // Desktop or other fallback
  if (app === "phonepe") return `phonepe://pay?${base}`;
  if (app === "gpay") return `tez://upi/pay?${base}`;
  if (app === "paytm") return `paytmmp://pay?${base}`;
  return `upi://pay?${base}`;
}

export function UpiPaymentCheckout({
  amount = 0,
  items = [],
  customerName = "Customer",
  upiId = "anshidop@upi",
  merchantName = "Premium Hub",
  supportPhone = "+917012958322",
  apiBaseUrl = "",
  onSuccess,
  onCancel,
}) {
  const [step, setStep] = useState("active"); // "active" | "done" | "failed"
  const [orderId, setOrderId] = useState(null);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState("");
  const [showQrOnMobile, setShowQrOnMobile] = useState(false);
  const [copiedVpa, setCopiedVpa] = useState(false);
  const [statusMsg, setStatusMsg] = useState("");
  const [secondsLeft, setSecondsLeft] = useState(480); // 8 minutes countdown

  // Optional manual UTR reference submission
  const [showUtrInput, setShowUtrInput] = useState(false);
  const [utrNumber, setUtrNumber] = useState("");
  const [utrSubmitted, setUtrSubmitted] = useState(false);

  const isMobile =
    typeof navigator !== "undefined" &&
    /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

  const baseEndpoint = (apiBaseUrl ? apiBaseUrl.replace(/\/$/, "") : "") + "/api/orders";

  // 1. Create order session immediately
  useEffect(() => {
    let active = true;
    const formattedItems = (items || []).map((i) => ({
      name: i.name || i.product?.name || "Item",
      variation: i.variation?.name || i.variation || "Plan",
      qty: i.quantity || i.qty || 1,
      price: i.lineTotal || i.price || amount,
    }));

    fetch(baseEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        items: formattedItems.length ? formattedItems : [{ name: "Subscription", variation: "Standard", qty: 1, price: amount }],
        total: amount,
        customerName,
        upiApp: isMobile ? "mobile_upi" : "qr_scan",
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (active && data.id) setOrderId(data.id);
      })
      .catch((err) => console.error("Order creation error:", err));

    return () => {
      active = false;
    };
  }, [baseEndpoint, amount]);

  // 2. Dynamic QR code generator
  useEffect(() => {
    const uri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(merchantName)}&am=${encodeURIComponent(Number(amount).toFixed(2))}&cu=INR&tn=Order`;

    const generateQR = (qrLib) => {
      qrLib.toDataURL(uri, {
        width: 260,
        margin: 1,
        color: { dark: "#0f172a", light: "#ffffff" },
        errorCorrectionLevel: "M",
      })
        .then(setQrCodeDataUrl)
        .catch((err) => console.error("QR Code generation error:", err));
    };

    if (QRCodeLib) {
      generateQR(QRCodeLib);
    } else {
      import("qrcode")
        .then((mod) => {
          const lib = mod.default || mod;
          generateQR(lib);
        })
        .catch(() => {
          // Fallback to public QR image API if qrcode package is missing
          const fallbackUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=4&data=${encodeURIComponent(uri)}`;
          setQrCodeDataUrl(fallbackUrl);
        });
    }
  }, [amount, upiId, merchantName]);

  // 3. Countdown timer
  useEffect(() => {
    if (step !== "active" || secondsLeft <= 0) return;
    const timer = setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(timer);
  }, [step, secondsLeft]);

  // 4. Background polling loop checking order status
  useEffect(() => {
    if (step !== "active" || !orderId) return;
    let active = true;

    const poll = async () => {
      try {
        const res = await fetch(`${baseEndpoint}?id=${encodeURIComponent(orderId)}`, { cache: "no-store" });
        if (!res.ok) return;
        const data = await res.json();
        if (!active) return;

        if (data.status === "confirmed") {
          playSuccessChime();
          triggerPaymentConfetti();
          setStep("done");
          if (onSuccess) onSuccess({ id: orderId, items, total: amount });
        } else if (data.status === "rejected") {
          setStep("failed");
          setStatusMsg("Payment was declined or timed out. Please contact us on WhatsApp.");
        }
      } catch {}
    };

    poll();
    const interval = setInterval(poll, 3000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [step, orderId, baseEndpoint, onSuccess, items, amount]);

  const handleAppClick = (app) => {
    const link = getUpiLink(app, amount, upiId, merchantName);
    window.location.href = link;
  };

  const copyVpa = () => {
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(upiId);
      setCopiedVpa(true);
      setTimeout(() => setCopiedVpa(false), 2000);
    }
  };

  const handleManualUtrSubmit = async (e) => {
    e.preventDefault();
    const cleanUtr = utrNumber.trim();
    if (!cleanUtr || !orderId) return;

    try {
      await fetch(baseEndpoint, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: orderId, utr: cleanUtr }),
      });
      setUtrSubmitted(true);
    } catch {
      setUtrSubmitted(true);
    }
  };

  const formatTimer = (secs) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  if (step === "done") {
    return (
      <OrderCompletedClaimScreen
        orderId={orderId}
        items={items}
        total={amount}
        supportPhone={supportPhone}
        merchantName={merchantName}
        onBackToStore={onCancel}
      />
    );
  }

  if (step === "failed") {
    return (
      <div className="upi-result upi-failed">
        <span className="upi-result-icon">&#x274C;</span>
        <h3>Payment Declined</h3>
        <p>{statusMsg || "We could not verify your payment. Please try again or reach out on WhatsApp."}</p>
        <button type="button" className="upi-toggle-btn" onClick={onCancel} style={{ marginTop: 12 }}>
          &larr; Return to Cart
        </button>
      </div>
    );
  }

  const shouldShowQr = !isMobile || showQrOnMobile;

  return (
    <div className="upi-checkout">
      <div className="upi-checkout-header">
        <h3>Fast UPI Payment</h3>
        <p>Auto-detecting payment &middot; Zero transaction fee</p>
        <div className="upi-amount-pill">
          <span>Amount:</span>
          <strong>{formatCurrency(amount)}</strong>
        </div>
      </div>

      <div style={{ textAlign: "center" }}>
        <div className="upi-live-status">
          <span className="upi-pulse-dot" />
          <span>Waiting for payment...</span>
        </div>
        <div className="upi-timer-badge">
          Session expires in <strong>{formatTimer(secondsLeft)}</strong>
        </div>
      </div>

      {shouldShowQr && (
        <div className="upi-qr-card">
          <div className="upi-qr-image-wrap">
            {qrCodeDataUrl ? (
              <img src={qrCodeDataUrl} alt="UPI QR Code" className="upi-qr-img" />
            ) : (
              <div style={{ width: 210, height: 210, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <span>Generating secure QR...</span>
              </div>
            )}
            <span className="upi-qr-badge">{formatCurrency(amount)}</span>
          </div>

          <p className="upi-qr-hint">Scan with any UPI app to pay</p>
          <p className="upi-qr-subtext">PhonePe, Google Pay, Paytm, CRED or BHIM</p>

          <div className="upi-vpa-copy-row">
            <span>UPI ID: <strong>{upiId}</strong></span>
            <button type="button" className="upi-vpa-copy-btn" onClick={copyVpa}>
              {copiedVpa ? "Copied!" : "Copy"}
            </button>
          </div>
        </div>
      )}

      <div>
        <div className="upi-apps-label">
          {isMobile ? "Tap to Pay with UPI App" : "Or Pay Directly on this Device"}
        </div>
        <div className="upi-apps-grid">
          <button
            type="button"
            className="upi-app-btn"
            onClick={() => handleAppClick("phonepe")}
          >
            <PhonePeLogo size={32} />
            <span>PhonePe</span>
          </button>

          <button
            type="button"
            className="upi-app-btn"
            onClick={() => handleAppClick("gpay")}
          >
            <GPayLogo size={32} />
            <span>GPay</span>
          </button>

          <button
            type="button"
            className="upi-app-btn"
            onClick={() => handleAppClick("paytm")}
          >
            <PaytmLogo size={32} />
            <span>Paytm</span>
          </button>

          <button
            type="button"
            className="upi-app-btn"
            onClick={() => handleAppClick("upi")}
          >
            <UpiLogo size={32} />
            <span>Any UPI</span>
          </button>
        </div>
      </div>

      {isMobile && (
        <button
          type="button"
          className="upi-toggle-btn"
          onClick={() => setShowQrOnMobile(!showQrOnMobile)}
        >
          {showQrOnMobile ? "Hide QR Code" : "📷 Show QR Code to scan from another phone"}
        </button>
      )}

      {/* Manual UTR reference submission option */}
      <div style={{ marginTop: 12 }}>
        {!showUtrInput ? (
          <button
            type="button"
            className="ghost"
            style={{ width: "100%", fontSize: "0.82rem", color: "#64748b" }}
            onClick={() => setShowUtrInput(true)}
          >
            Already paid? Submit 12-digit UPI Ref / UTR &rarr;
          </button>
        ) : utrSubmitted ? (
          <div style={{ padding: "8px 12px", background: "#f0fdf4", color: "#166534", borderRadius: 8, fontSize: "0.85rem", textAlign: "center" }}>
            ✅ Ref #{utrNumber} submitted! Admin is verifying now.
          </div>
        ) : (
          <form onSubmit={handleManualUtrSubmit} style={{ display: "flex", gap: 6, marginTop: 4 }}>
            <input
              type="text"
              placeholder="Enter 12-digit UTR / Ref No."
              value={utrNumber}
              onChange={(e) => setUtrNumber(e.target.value)}
              style={{ flex: 1, padding: "8px 12px", border: "1px solid #cbd5e1", borderRadius: 8, fontSize: "0.85rem" }}
            />
            <button
              type="submit"
              className="order-confirm-btn"
              style={{ padding: "8px 14px", fontSize: "0.82rem" }}
            >
              Submit
            </button>
          </form>
        )}
      </div>

      <p className="upi-auto-hint">
        Do not refresh or close this tab. Once paid, the screen confirms automatically.
      </p>

      {orderId && (
        <div style={{ textAlign: "center", marginTop: 4 }}>
          <small className="upi-order-ref">Session: {orderId}</small>
        </div>
      )}

      {onCancel && (
        <button type="button" className="upi-cancel-btn" onClick={onCancel}>
          &larr; Cancel and return
        </button>
      )}
    </div>
  );
}
export default UpiPaymentCheckout;
