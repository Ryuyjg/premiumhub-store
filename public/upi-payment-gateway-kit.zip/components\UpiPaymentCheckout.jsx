import FoodUpiCheckout from "./FoodUpiCheckout.jsx";
export { FoodUpiCheckout };
export { FoodUpiCheckout as UpiPaymentCheckout };
export default FoodUpiCheckout;
