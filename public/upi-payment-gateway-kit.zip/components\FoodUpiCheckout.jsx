import React, { useState, useEffect } from "react";
import { PhonePeLogo, GPayLogo, PaytmLogo, UpiLogo } from "./UpiLogos.jsx";
import { FoodOrderSuccessScreen } from "./FoodOrderSuccessScreen.jsx";
import { playSuccessChime, triggerPaymentConfetti } from "./celebration.js";

let QRCodeLib = null;
try {
  import("qrcode").then((mod) => {
    QRCodeLib = mod.default || mod;
  }).catch(() => {});
} catch {}

function formatCurrency(val) {
  return "₹" + Number(val || 0).toLocaleString("en-IN");
}

/**
 * Builds native UPI deep link for Android and iOS devices
 */
export function getUpiLink(app, amount, upiId, restaurantName) {
  const isAndroid = typeof navigator !== "undefined" && /Android/i.test(navigator.userAgent);
  const isIOS = typeof navigator !== "undefined" && /iPhone|iPad|iPod/i.test(navigator.userAgent);
  const amt = Number(amount).toFixed(2);
  const base = `pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(restaurantName)}&am=${encodeURIComponent(amt)}&cu=INR&tn=FoodOrder`;

  if (isAndroid) {
    if (app === "phonepe") {
      return `intent://pay?${base}#Intent;scheme=upi;package=com.phonepe.app;end`;
    }
    if (app === "gpay") {
      return `intent://pay?${base}#Intent;scheme=upi;package=com.google.android.apps.nbu.paisa.user;end`;
    }
    if (app === "paytm") {
      return `intent://pay?${base}#Intent;scheme=upi;package=net.one97.paytm;end`;
    }
    return `upi://pay?${base}`;
  }

  if (isIOS) {
    if (app === "phonepe") return `phonepe://pay?${base}`;
    if (app === "gpay") return `gpay://upi/pay?${base}`;
    if (app === "paytm") return `paytmmp://pay?${base}`;
    return `upi://pay?${base}`;
  }

  if (app === "phonepe") return `phonepe://pay?${base}`;
  if (app === "gpay") return `tez://upi/pay?${base}`;
  if (app === "paytm") return `paytmmp://pay?${base}`;
  return `upi://pay?${base}`;
}

export function FoodUpiCheckout({
  amount = 0,
  items = [],
  customerName = "Customer",
  customerPhone = "",
  deliveryAddress = "",
  deliveryNotes = "",
  subtotal = 0,
  deliveryFee = 0,
  upiId = "anshidop@upi",
  restaurantName = "Royal Spice Kitchen",
  restaurantPhone = "+917012958322",
  apiBaseUrl = "http://localhost:5000",
  onSuccess,
  onCancel,
}) {
  const [step, setStep] = useState("active"); // active | done | failed
  const [orderId, setOrderId] = useState(null);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState("");
  const [showQrOnMobile, setShowQrOnMobile] = useState(false);
  const [copiedVpa, setCopiedVpa] = useState(false);
  const [statusMsg, setStatusMsg] = useState("");
  const [secondsLeft, setSecondsLeft] = useState(480); // 8 minutes

  // Optional manual UTR reference
  const [showUtrInput, setShowUtrInput] = useState(false);
  const [utrNumber, setUtrNumber] = useState("");
  const [utrSubmitted, setUtrSubmitted] = useState(false);

  const isMobile =
    typeof navigator !== "undefined" &&
    /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

  const baseEndpoint = (apiBaseUrl ? apiBaseUrl.replace(/\/$/, "") : "") + "/api/orders";

  // 1. Create food delivery order session
  useEffect(() => {
    let active = true;

    fetch(baseEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customerName,
        customerPhone,
        deliveryAddress,
        notes: deliveryNotes,
        items,
        subtotal: subtotal || amount,
        deliveryFee,
        total: amount,
        upiApp: isMobile ? "mobile_upi" : "qr_scan",
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (active && data.id) setOrderId(data.id);
      })
      .catch((err) => console.error("Food order creation error:", err));

    return () => {
      active = false;
    };
  }, [baseEndpoint, amount]);

  // 2. Generate dynamic QR code with exact amount & restaurant VPA
  useEffect(() => {
    const uri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(restaurantName)}&am=${encodeURIComponent(Number(amount).toFixed(2))}&cu=INR&tn=FoodOrder`;

    const generateQR = (qrLib) => {
      qrLib.toDataURL(uri, {
        width: 260,
        margin: 1,
        color: { dark: "#0f172a", light: "#ffffff" },
        errorCorrectionLevel: "M",
      })
        .then(setQrCodeDataUrl)
        .catch((err) => console.error("QR Code Error:", err));
    };

    if (QRCodeLib) {
      generateQR(QRCodeLib);
    } else {
      import("qrcode")
        .then((mod) => {
          const lib = mod.default || mod;
          generateQR(lib);
        })
        .catch(() => {
          const fallbackUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=4&data=${encodeURIComponent(uri)}`;
          setQrCodeDataUrl(fallbackUrl);
        });
    }
  }, [amount, upiId, restaurantName]);

  // 3. Countdown timer
  useEffect(() => {
    if (step !== "active" || secondsLeft <= 0) return;
    const timer = setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(timer);
  }, [step, secondsLeft]);

  // 4. Background polling loop checking if restaurant confirmed payment
  useEffect(() => {
    if (step !== "active" || !orderId) return;
    let active = true;

    const poll = async () => {
      try {
        const res = await fetch(`${baseEndpoint}?id=${encodeURIComponent(orderId)}`, { cache: "no-store" });
        if (!res.ok) return;
        const data = await res.json();
        if (!active) return;

        // When restaurant marks confirmed or preparing
        if (["confirmed", "preparing", "out_for_delivery", "delivered"].includes(data.status)) {
          playSuccessChime();
          triggerPaymentConfetti();
          setStep("done");
          if (onSuccess) onSuccess({ id: orderId, items, total: amount });
        } else if (data.status === "rejected") {
          setStep("failed");
          setStatusMsg("Order was declined by the restaurant. If money was deducted, it will auto-refund.");
        }
      } catch {}
    };

    poll();
    const interval = setInterval(poll, 3000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [step, orderId, baseEndpoint, onSuccess, items, amount]);

  const handleAppClick = (app) => {
    const link = getUpiLink(app, amount, upiId, restaurantName);
    window.location.href = link;
  };

  const copyVpa = () => {
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(upiId);
      setCopiedVpa(true);
      setTimeout(() => setCopiedVpa(false), 2000);
    }
  };

  const handleManualUtrSubmit = async (e) => {
    e.preventDefault();
    const cleanUtr = utrNumber.trim();
    if (!cleanUtr || !orderId) return;

    try {
      await fetch(baseEndpoint, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: orderId, utr: cleanUtr }),
      });
      setUtrSubmitted(true);
    } catch {
      setUtrSubmitted(true);
    }
  };

  const formatTimer = (secs) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  if (step === "done") {
    return (
      <FoodOrderSuccessScreen
        orderId={orderId}
        customerName={customerName}
        customerPhone={customerPhone}
        deliveryAddress={deliveryAddress}
        items={items}
        total={amount}
        restaurantName={restaurantName}
        restaurantPhone={restaurantPhone}
        onBackToMenu={onCancel}
      />
    );
  }

  if (step === "failed") {
    return (
      <div className="upi-result upi-failed">
        <span className="upi-result-icon">&#x274C;</span>
        <h3>Order Declined</h3>
        <p>{statusMsg || "The restaurant could not accept the order."}</p>
        <button type="button" className="upi-toggle-btn" onClick={onCancel} style={{ marginTop: 12 }}>
          &larr; Return to Cart
        </button>
      </div>
    );
  }

  const shouldShowQr = !isMobile || showQrOnMobile;

  return (
    <div className="upi-checkout">
      <div className="upi-checkout-header">
        <h3>Fast UPI Payment</h3>
        <p>{restaurantName} &middot; Zero transaction fee</p>
        <div className="upi-amount-pill">
          <span>Total Bill:</span>
          <strong>{formatCurrency(amount)}</strong>
        </div>
      </div>

      {/* Delivery Summary Pill */}
      {deliveryAddress && (
        <div style={{ margin: "10px 0", padding: "8px 12px", background: "#f8fafc", borderRadius: 8, fontSize: "0.82rem", color: "#475569", border: "1px solid #e2e8f0" }}>
          📍 Deliver to: <strong>{deliveryAddress}</strong>
        </div>
      )}

      <div style={{ textAlign: "center" }}>
        <div className="upi-live-status">
          <span className="upi-pulse-dot" />
          <span>Waiting for UPI payment...</span>
        </div>
        <div className="upi-timer-badge">
          Session expires in <strong>{formatTimer(secondsLeft)}</strong>
        </div>
      </div>

      {shouldShowQr && (
        <div className="upi-qr-card">
          <div className="upi-qr-image-wrap">
            {qrCodeDataUrl ? (
              <img src={qrCodeDataUrl} alt="UPI QR Code" className="upi-qr-img" />
            ) : (
              <div style={{ width: 210, height: 210, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <span>Generating QR...</span>
              </div>
            )}
            <span className="upi-qr-badge">{formatCurrency(amount)}</span>
          </div>

          <p className="upi-qr-hint">Scan with any UPI app to pay</p>
          <p className="upi-qr-subtext">PhonePe, Google Pay, Paytm, CRED or BHIM</p>

          <div className="upi-vpa-copy-row">
            <span>UPI ID: <strong>{upiId}</strong></span>
            <button type="button" className="upi-vpa-copy-btn" onClick={copyVpa}>
              {copiedVpa ? "Copied!" : "Copy"}
            </button>
          </div>
        </div>
      )}

      <div>
        <div className="upi-apps-label">
          {isMobile ? "Tap to Pay with UPI App" : "Or Pay Directly on this Device"}
        </div>
        <div className="upi-apps-grid">
          <button
            type="button"
            className="upi-app-btn"
            onClick={() => handleAppClick("phonepe")}
          >
            <PhonePeLogo size={32} />
            <span>PhonePe</span>
          </button>

          <button
            type="button"
            className="upi-app-btn"
            onClick={() => handleAppClick("gpay")}
          >
            <GPayLogo size={32} />
            <span>GPay</span>
          </button>

          <button
            type="button"
            className="upi-app-btn"
            onClick={() => handleAppClick("paytm")}
          >
            <PaytmLogo size={32} />
            <span>Paytm</span>
          </button>

          <button
            type="button"
            className="upi-app-btn"
            onClick={() => handleAppClick("upi")}
          >
            <UpiLogo size={32} />
            <span>Any UPI</span>
          </button>
        </div>
      </div>

      {isMobile && (
        <button
          type="button"
          className="upi-toggle-btn"
          onClick={() => setShowQrOnMobile(!showQrOnMobile)}
        >
          {showQrOnMobile ? "Hide QR Code" : "📷 Show QR Code to scan from another phone"}
        </button>
      )}

      {/* Optional UTR Submission */}
      <div style={{ marginTop: 12 }}>
        {!showUtrInput ? (
          <button
            type="button"
            className="ghost"
            style={{ width: "100%", fontSize: "0.82rem", color: "#64748b" }}
            onClick={() => setShowUtrInput(true)}
          >
            Already paid? Submit 12-digit UPI UTR / Ref No. &rarr;
          </button>
        ) : utrSubmitted ? (
          <div style={{ padding: "8px 12px", background: "#f0fdf4", color: "#166534", borderRadius: 8, fontSize: "0.85rem", textAlign: "center" }}>
            ✅ Ref #{utrNumber} submitted! Kitchen is verifying your payment.
          </div>
        ) : (
          <form onSubmit={handleManualUtrSubmit} style={{ display: "flex", gap: 6, marginTop: 4 }}>
            <input
              type="text"
              placeholder="Enter 12-digit UTR No."
              value={utrNumber}
              onChange={(e) => setUtrNumber(e.target.value)}
              style={{ flex: 1, padding: "8px 12px", border: "1px solid #cbd5e1", borderRadius: 8, fontSize: "0.85rem" }}
            />
            <button
              type="submit"
              className="order-confirm-btn"
              style={{ padding: "8px 14px", fontSize: "0.82rem" }}
            >
              Submit
            </button>
          </form>
        )}
      </div>

      <p className="upi-auto-hint">
        Do not close this screen. Once paid, the kitchen receives your order automatically.
      </p>

      {orderId && (
        <div style={{ textAlign: "center", marginTop: 4 }}>
          <small className="upi-order-ref">Order Ref: {orderId}</small>
        </div>
      )}

      {onCancel && (
        <button type="button" className="upi-cancel-btn" onClick={onCancel}>
          &larr; Cancel and return
        </button>
      )}
    </div>
  );
}

export default FoodUpiCheckout;
