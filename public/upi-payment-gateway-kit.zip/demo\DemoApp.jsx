import React, { useState } from "react";
import UpiPaymentCheckout from "../components/UpiPaymentCheckout.jsx";
import OrdersAdmin from "../components/OrdersAdmin.jsx";
import "../styles/upi.css";

export default function DemoApp() {
  const [activeTab, setActiveTab] = useState("store"); // "store" | "admin"
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [lastSuccess, setLastSuccess] = useState(null);

  // Sample cart / product
  const sampleItems = [
    { name: "Netflix Premium 4K", variation: "1 Month UHD", qty: 1, price: 199 },
    { name: "Spotify Premium", variation: "3 Months Individual", qty: 1, price: 99 },
  ];
  const sampleTotal = sampleItems.reduce((acc, item) => acc + item.price * item.qty, 0);

  return (
    <div style={{ fontFamily: "system-ui, -apple-system, sans-serif", minHeight: "100vh", background: "#f8fafc", padding: 20 }}>
      {/* Top Demo Bar */}
      <div style={{ maxWidth: 800, margin: "0 auto 20px", display: "flex", justifyContent: "space-between", alignItems: "center", background: "#ffffff", padding: "12px 20px", borderRadius: 12, border: "1px solid #e2e8f0" }}>
        <div>
          <strong style={{ fontSize: "1.1rem" }}>⚡ UPI Payment Gateway Demo</strong>
          <span style={{ fontSize: "0.85rem", color: "#64748b", marginLeft: 10 }}>Plug & Play Kit</span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button
            type="button"
            className={`order-filter-btn ${activeTab === "store" ? "active" : "ghost"}`}
            onClick={() => setActiveTab("store")}
          >
            🛒 Customer View
          </button>
          <button
            type="button"
            className={`order-filter-btn ${activeTab === "admin" ? "active" : "ghost"}`}
            onClick={() => setActiveTab("admin")}
          >
            🛡️ Admin Verification
          </button>
        </div>
      </div>

      <div style={{ maxWidth: 640, margin: "0 auto" }}>
        {activeTab === "store" && (
          <div>
            {!checkoutOpen ? (
              <div style={{ background: "#ffffff", padding: 24, borderRadius: 16, border: "1px solid #e2e8f0", boxShadow: "0 4px 12px rgba(0,0,0,0.03)" }}>
                <h3 style={{ marginTop: 0 }}>Shopping Cart</h3>
                <div style={{ display: "grid", gap: 10, margin: "16px 0" }}>
                  {sampleItems.map((item, i) => (
                    <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid #f1f5f9" }}>
                      <span><strong>{item.name}</strong> ({item.variation}) x {item.qty}</span>
                      <strong>₹{item.price}</strong>
                    </div>
                  ))}
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "1.2rem", fontWeight: 800, margin: "20px 0" }}>
                  <span>Total Amount</span>
                  <span style={{ color: "#2563eb" }}>₹{sampleTotal}</span>
                </div>

                <button
                  type="button"
                  style={{ width: "100%", padding: "14px", background: "#2563eb", color: "#ffffff", border: 0, borderRadius: 10, fontSize: "1rem", fontWeight: 700, cursor: "pointer" }}
                  onClick={() => setCheckoutOpen(true)}
                >
                  Pay with UPI &rarr;
                </button>
                <small style={{ display: "block", textAlign: "center", marginTop: 10, color: "#94a3b8" }}>
                  Opens dynamic QR & PhonePe, GPay, Paytm 1-tap buttons
                </small>
              </div>
            ) : (
              <UpiPaymentCheckout
                amount={sampleTotal}
                items={sampleItems}
                customerName="John Doe"
                upiId="anshidop@upi"
                merchantName="Premium Hub"
                supportPhone="+917012958322"
                onSuccess={(data) => {
                  setLastSuccess(data);
                }}
                onCancel={() => setCheckoutOpen(false)}
              />
            )}
          </div>
        )}

        {activeTab === "admin" && (
          <div style={{ background: "#ffffff", padding: 20, borderRadius: 16, border: "1px solid #e2e8f0" }}>
            <OrdersAdmin />
          </div>
        )}
      </div>
    </div>
  );
}
