import React, { useState } from "react";
import FoodUpiCheckout from "../components/FoodUpiCheckout.jsx";
import RestaurantOrdersAdmin from "../components/RestaurantOrdersAdmin.jsx";
import "../styles/upi.css";

export default function FoodAppDemo() {
  const [activeTab, setActiveTab] = useState("customer"); // "customer" | "kitchen"
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  // Customer delivery details
  const [customerName, setCustomerName] = useState("Rahul Sharma");
  const [customerPhone, setCustomerPhone] = useState("+91 98765 43210");
  const [deliveryAddress, setDeliveryAddress] = useState("Flat 402, Green Valley Apts, MG Road");
  const [notes, setNotes] = useState("Ring bell, don't call");

  // Sample food cart
  const foodItems = [
    { name: "Hyderabadi Chicken Biryani", qty: 2, price: 340 },
    { name: "Butter Garlic Naan", qty: 3, price: 120 },
    { name: "Gulab Jamun (2 Pcs)", qty: 1, price: 60 },
  ];
  const deliveryFee = 40;
  const subtotal = foodItems.reduce((acc, item) => acc + item.price, 0);
  const total = subtotal + deliveryFee;

  return (
    <div style={{ fontFamily: "system-ui, -apple-system, sans-serif", minHeight: "100vh", background: "#f8fafc", padding: 16 }}>
      {/* Top Demo Navigation */}
      <div style={{ maxWidth: 840, margin: "0 auto 20px", display: "flex", justifyContent: "space-between", alignItems: "center", background: "#ffffff", padding: "12px 20px", borderRadius: 14, border: "1px solid #e2e8f0" }}>
        <div>
          <strong style={{ fontSize: "1.15rem", color: "#0f172a" }}>🍲 Food Delivery UPI Gateway</strong>
          <span style={{ fontSize: "0.85rem", color: "#64748b", marginLeft: 10 }}>Standalone Express / Node Kit</span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button
            type="button"
            className={`order-filter-btn ${activeTab === "customer" ? "active" : "ghost"}`}
            onClick={() => setActiveTab("customer")}
          >
            🛵 Customer App
          </button>
          <button
            type="button"
            className={`order-filter-btn ${activeTab === "kitchen" ? "active" : "ghost"}`}
            onClick={() => setActiveTab("kitchen")}
          >
            👨‍🍳 Kitchen / Admin Panel
          </button>
        </div>
      </div>

      <div style={{ maxWidth: 600, margin: "0 auto" }}>
        {activeTab === "customer" && (
          <div>
            {!checkoutOpen ? (
              <div style={{ background: "#ffffff", padding: 24, borderRadius: 16, border: "1px solid #e2e8f0", boxShadow: "0 4px 12px rgba(0,0,0,0.03)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #f1f5f9", paddingBottom: 12 }}>
                  <div>
                    <h3 style={{ margin: 0 }}>Spice Garden Restaurant</h3>
                    <small style={{ color: "#64748b" }}>Order Summary & Delivery Details</small>
                  </div>
                  <span style={{ padding: "4px 8px", background: "#ecfdf5", color: "#059669", borderRadius: 6, fontSize: "0.8rem", fontWeight: 700 }}>
                    30-40 mins
                  </span>
                </div>

                {/* Delivery Form */}
                <div style={{ margin: "16px 0", display: "grid", gap: 10 }}>
                  <div>
                    <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#475569", marginBottom: 4 }}>
                      Customer Name & Phone:
                    </label>
                    <div style={{ display: "flex", gap: 8 }}>
                      <input
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="Your Name"
                        style={{ flex: 1, padding: "8px 12px", border: "1px solid #cbd5e1", borderRadius: 8, fontSize: "0.88rem" }}
                      />
                      <input
                        type="text"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="Phone Number"
                        style={{ flex: 1, padding: "8px 12px", border: "1px solid #cbd5e1", borderRadius: 8, fontSize: "0.88rem" }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#475569", marginBottom: 4 }}>
                      Delivery Address:
                    </label>
                    <input
                      type="text"
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="House/Flat No, Apartment, Street"
                      style={{ width: "100%", padding: "8px 12px", border: "1px solid #cbd5e1", borderRadius: 8, fontSize: "0.88rem", boxSizing: "border-box" }}
                    />
                  </div>
                </div>

                {/* Items List */}
                <div style={{ margin: "16px 0", borderTop: "1px dashed #e2e8f0", paddingTop: 12 }}>
                  <span style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "#64748b", textTransform: "uppercase", marginBottom: 8 }}>
                    Items in Cart:
                  </span>
                  {foodItems.map((item, idx) => (
                    <div key={idx} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", fontSize: "0.9rem" }}>
                      <span>{item.name} &times; {item.qty}</span>
                      <strong>₹{item.price}</strong>
                    </div>
                  ))}
                  <div style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", fontSize: "0.88rem", color: "#64748b" }}>
                    <span>Delivery Partner Fee</span>
                    <span>₹{deliveryFee}</span>
                  </div>
                </div>

                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "1.25rem", fontWeight: 800, margin: "16px 0", paddingTop: 10, borderTop: "1.5px solid #0f172a" }}>
                  <span>To Pay</span>
                  <span style={{ color: "#16a34a" }}>₹{total}</span>
                </div>

                <button
                  type="button"
                  style={{ width: "100%", padding: "14px", background: "#16a34a", color: "#ffffff", border: 0, borderRadius: 10, fontSize: "1.05rem", fontWeight: 700, cursor: "pointer" }}
                  onClick={() => setCheckoutOpen(true)}
                >
                  Pay ₹{total} via UPI & Place Order &rarr;
                </button>
                <small style={{ display: "block", textAlign: "center", marginTop: 10, color: "#94a3b8" }}>
                  Instant QR code & PhonePe, GPay, Paytm 1-tap app launch
                </small>
              </div>
            ) : (
              <FoodUpiCheckout
                amount={total}
                subtotal={subtotal}
                deliveryFee={deliveryFee}
                items={foodItems}
                customerName={customerName}
                customerPhone={customerPhone}
                deliveryAddress={deliveryAddress}
                deliveryNotes={notes}
                upiId="anshidop@upi"
                restaurantName="Spice Garden Restaurant"
                restaurantPhone="+917012958322"
                apiBaseUrl="http://localhost:5000"
                onCancel={() => setCheckoutOpen(false)}
              />
            )}
          </div>
        )}

        {activeTab === "kitchen" && (
          <div style={{ background: "#ffffff", padding: 16, borderRadius: 16, border: "1px solid #e2e8f0" }}>
            <RestaurantOrdersAdmin apiBaseUrl="http://localhost:5000" />
          </div>
        )}
      </div>
    </div>
  );
}
