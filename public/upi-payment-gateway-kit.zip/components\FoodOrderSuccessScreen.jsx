import React, { useState, useEffect } from "react";
import { playSuccessChime, triggerPaymentConfetti } from "./celebration.js";

function formatCurrency(val) {
  return "₹" + Number(val || 0).toLocaleString("en-IN");
}

export function FoodOrderSuccessScreen({
  orderId,
  customerName = "Customer",
  customerPhone = "",
  deliveryAddress = "",
  items = [],
  total = 0,
  restaurantName = "Royal Spice Kitchen",
  restaurantPhone = "+917012958322",
  onBackToMenu,
}) {
  const [showBillModal, setShowBillModal] = useState(false);

  useEffect(() => {
    playSuccessChime();
    triggerPaymentConfetti();
  }, []);

  const cleanPhone = String(restaurantPhone).replace(/[^\d]/g, "");
  const itemsList = Array.isArray(items) ? items : [];

  const itemsText = itemsList
    .map((i) => `- ${i.name || "Item"} x ${i.qty || i.quantity || 1} (${formatCurrency(i.price || i.lineTotal)})`)
    .join("\n");

  const waMessage = `Hello ${restaurantName}! 🍲\nI have completed my UPI payment for food delivery.\n\n📦 Order ID: ${orderId || "PAID"}\n👤 Name: ${customerName}\n📱 Phone: ${customerPhone}\n📍 Delivery Address: ${deliveryAddress}\n\n🍽️ Ordered Items:\n${itemsText}\n💰 Total Paid: ${formatCurrency(total)} (Payment Verified)\n\nPlease start preparing my food. Thank you!`;

  const waUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(waMessage)}`;

  return (
    <div className="claim-card" style={{ maxWidth: 520, margin: "0 auto", textAlign: "center" }}>
      <span className="claim-icon" style={{ fontSize: "3rem" }}>🎉</span>
      <h2 className="claim-title" style={{ fontSize: "1.45rem", margin: "10px 0 6px", color: "#0f172a" }}>
        Order Placed & Payment Verified!
      </h2>
      <p className="claim-subtitle" style={{ fontSize: "0.92rem", color: "#475569", lineHeight: 1.5, marginBottom: 18 }}>
        Your payment was confirmed. The kitchen has received your order and is preparing your food!
      </p>

      {/* Food Delivery Live Progress Tracker */}
      <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 14, padding: "16px 12px", marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", position: "relative" }}>
          <div style={{ flex: 1, textAlign: "center" }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#16a34a", color: "#fff", display: "grid", placeItems: "center", margin: "0 auto 6px", fontWeight: 700, fontSize: "1rem" }}>
              ✓
            </div>
            <strong style={{ display: "block", fontSize: "0.8rem", color: "#16a34a" }}>Paid</strong>
          </div>

          <div style={{ flex: 1, textAlign: "center" }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#2563eb", color: "#fff", display: "grid", placeItems: "center", margin: "0 auto 6px", fontWeight: 700, fontSize: "1rem", boxShadow: "0 0 0 4px #dbeafe" }}>
              🍳
            </div>
            <strong style={{ display: "block", fontSize: "0.8rem", color: "#2563eb" }}>Kitchen Preparing</strong>
          </div>

          <div style={{ flex: 1, textAlign: "center" }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#e2e8f0", color: "#64748b", display: "grid", placeItems: "center", margin: "0 auto 6px", fontWeight: 700, fontSize: "1rem" }}>
              🛵
            </div>
            <strong style={{ display: "block", fontSize: "0.8rem", color: "#64748b" }}>On the Way</strong>
          </div>
        </div>
      </div>

      {/* Order Info & Address Box */}
      <div className="claim-details-box" style={{ textAlign: "left", marginBottom: 20 }}>
        <div className="claim-order-header">
          <span className="claim-order-id">Order Ref: {orderId || "VERIFIED"}</span>
          <span className="claim-verified-pill">PAID &bull; ₹{total}</span>
        </div>

        {deliveryAddress && (
          <div style={{ padding: "8px 0", borderBottom: "1px dashed #e2e8f0", fontSize: "0.86rem" }}>
            <strong style={{ color: "#64748b", display: "block", fontSize: "0.75rem", textTransform: "uppercase" }}>Delivery Address:</strong>
            <span style={{ color: "#1e293b" }}>{deliveryAddress}</span>
            {customerPhone && <span style={{ display: "block", color: "#64748b", fontSize: "0.8rem", marginTop: 2 }}>Contact: {customerPhone}</span>}
          </div>
        )}

        <div style={{ marginTop: 8 }}>
          <strong style={{ color: "#64748b", display: "block", fontSize: "0.75rem", textTransform: "uppercase", marginBottom: 6 }}>Food Items:</strong>
          {itemsList.map((item, idx) => (
            <div key={idx} className="claim-item-row">
              <span>{item.name} x {item.qty || item.quantity || 1}</span>
              <strong>{formatCurrency(item.price || item.lineTotal)}</strong>
            </div>
          ))}
        </div>

        <div className="claim-total-row" style={{ marginTop: 10 }}>
          <span>Total Bill Paid</span>
          <span>{formatCurrency(total)}</span>
        </div>
      </div>

      {/* WhatsApp Kitchen Notification */}
      <a
        href={waUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="claim-wa-btn"
        style={{ marginBottom: 10 }}
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
        </svg>
        <span>Message Restaurant on WhatsApp</span>
      </a>

      {/* Printable Food Bill Receipt */}
      <button
        type="button"
        className="receipt-action-btn"
        onClick={() => setShowBillModal(true)}
      >
        📄 View & Print Food Bill / Invoice
      </button>

      {onBackToMenu && (
        <button
          type="button"
          onClick={onBackToMenu}
          className="ghost"
          style={{ width: "100%", marginTop: 14, fontSize: "0.88rem" }}
        >
          &larr; Order More Food
        </button>
      )}

      {/* Printable Invoice Modal */}
      {showBillModal && (
        <div className="receipt-modal-backdrop" onClick={() => setShowBillModal(false)}>
          <div className="receipt-paper" onClick={(e) => e.stopPropagation()}>
            <div className="receipt-header">
              <span>Food Delivery Tax Invoice / Cash Memo</span>
              <h3>{restaurantName}</h3>
              <small style={{ color: "#64748b" }}>Order & Delivery Receipt</small>
            </div>

            <div className="receipt-row">
              <span>Order No:</span>
              <strong>{orderId || "VERIFIED"}</strong>
            </div>
            <div className="receipt-row">
              <span>Date & Time:</span>
              <strong>{new Date().toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}</strong>
            </div>
            <div className="receipt-row">
              <span>Payment Mode:</span>
              <strong style={{ color: "#16a34a" }}>UPI (PAID & VERIFIED ✅)</strong>
            </div>

            <hr style={{ border: "none", borderTop: "1px dashed #e2e8f0", margin: "12px 0" }} />

            <div style={{ marginBottom: 12 }}>
              <span style={{ fontSize: "0.8rem", color: "#64748b", textTransform: "uppercase", fontWeight: 700, display: "block", marginBottom: 6 }}>
                Customer & Delivery Address:
              </span>
              <div style={{ fontSize: "0.85rem", color: "#1e293b" }}>
                <strong>{customerName}</strong> ({customerPhone})<br />
                {deliveryAddress}
              </div>
            </div>

            <hr style={{ border: "none", borderTop: "1px dashed #e2e8f0", margin: "12px 0" }} />

            <div style={{ marginBottom: 12 }}>
              <span style={{ fontSize: "0.8rem", color: "#64748b", textTransform: "uppercase", fontWeight: 700, display: "block", marginBottom: 6 }}>
                Ordered Items:
              </span>
              {itemsList.map((item, idx) => (
                <div key={idx} className="receipt-row">
                  <span>{item.name} x {item.qty || item.quantity || 1}</span>
                  <strong>{formatCurrency(item.price || item.lineTotal)}</strong>
                </div>
              ))}
            </div>

            <div className="receipt-row" style={{ borderTop: "1.5px solid #0f172a", paddingTop: 8, fontSize: "1rem" }}>
              <strong>Total Paid</strong>
              <strong>{formatCurrency(total)}</strong>
            </div>

            <div className="receipt-warranty-box" style={{ background: "#f8fafc", border: "1px solid #e2e8f0" }}>
              <h4 style={{ margin: "0 0 4px", fontSize: "0.85rem", color: "#0f172a" }}>🍲 Freshly Cooked Guarantee</h4>
              <p style={{ margin: 0, fontSize: "0.78rem", color: "#64748b" }}>
                Thank you for your order! In case of any feedback or delivery inquiry, please call {restaurantPhone}.
              </p>
            </div>

            <button type="button" className="receipt-print-btn" onClick={() => window.print()}>
              🖨️ Print / Save as PDF
            </button>
            <button
              type="button"
              className="ghost"
              style={{ width: "100%", marginTop: 8 }}
              onClick={() => setShowBillModal(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default FoodOrderSuccessScreen;
