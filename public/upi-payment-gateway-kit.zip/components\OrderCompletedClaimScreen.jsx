import React, { useState, useEffect } from "react";
import { playSuccessChime, triggerPaymentConfetti } from "./celebration.js";

function formatCurrency(val) {
  return "₹" + Number(val || 0).toLocaleString("en-IN");
}

export function OrderCompletedClaimScreen({
  orderId,
  items = [],
  total = 0,
  supportPhone = "+917012958322",
  merchantName = "Premium Hub",
  onBackToStore,
}) {
  const [showReceiptModal, setShowReceiptModal] = useState(false);

  useEffect(() => {
    playSuccessChime();
    triggerPaymentConfetti();
  }, []);

  const cleanPhone = String(supportPhone).replace(/[^\d]/g, "");
  const itemsList = Array.isArray(items) ? items : [];

  const itemsText = itemsList
    .map(
      (i) =>
        `- ${i.name || i.product?.name || "Product"} (${i.variation?.name || i.variation || "Plan"}) x ${i.quantity || i.qty || 1} - ${formatCurrency(i.lineTotal || i.price)}`
    )
    .join("\n");

  const waMessage = `Hello ${merchantName}! 🚀\nI have completed my payment on your store.\n\n📦 Order ID: ${orderId || "PAID"}\n🛍️ Items:\n${itemsText}\n💰 Total Paid: ${formatCurrency(total)} (Payment Verified)\n\nPlease share my order details / credentials here. Thank you!`;

  const waUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(waMessage)}`;

  return (
    <div className="claim-card">
      <span className="claim-icon">🎉</span>
      <h2 className="claim-title">Payment Confirmed & Verified!</h2>
      <p className="claim-subtitle">
        Your payment was received. Tap the button below to message us on WhatsApp and receive your delivery immediately.
      </p>

      <div className="claim-details-box">
        <div className="claim-order-header">
          <span className="claim-order-id">Order Ref: {orderId || "Verified"}</span>
          <span className="claim-verified-pill">PAID ✅</span>
        </div>

        {itemsList.map((item, idx) => (
          <div key={idx} className="claim-item-row">
            <span>
              <strong>{item.name || item.product?.name || "Item"}</strong> &middot; {item.variation?.name || item.variation || "Plan"} x {item.quantity || item.qty || 1}
            </span>
            <strong>{formatCurrency(item.lineTotal || item.price)}</strong>
          </div>
        ))}

        <div className="claim-total-row">
          <span>Total Paid</span>
          <span>{formatCurrency(total)}</span>
        </div>
      </div>

      <a
        href={waUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="claim-wa-btn"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
        </svg>
        <span>Chat on WhatsApp to Receive Order</span>
      </a>

      {/* Official Warranty Receipt Button */}
      <button
        type="button"
        className="receipt-action-btn"
        onClick={() => setShowReceiptModal(true)}
      >
        📄 View & Download Official Warranty Receipt
      </button>

      <div className="claim-support-note">
        Support Number: <strong className="claim-support-phone">{supportPhone}</strong>
        <br />
        Your order ID, products, and verified payment total will be sent automatically.
      </div>

      {onBackToStore && (
        <button
          type="button"
          onClick={onBackToStore}
          className="ghost"
          style={{ marginTop: 16, fontSize: "0.88rem" }}
        >
          &larr; Continue
        </button>
      )}

      {/* Official Printable Warranty Receipt Modal */}
      {showReceiptModal && (
        <div className="receipt-modal-backdrop" onClick={() => setShowReceiptModal(false)}>
          <div className="receipt-paper" onClick={(e) => e.stopPropagation()}>
            <div className="receipt-header">
              <span>Official Warranty Certificate</span>
              <h3>{merchantName}</h3>
              <small style={{ color: "#64748b" }}>Order & Warranty Receipt</small>
            </div>

            <div className="receipt-row">
              <span>Order Ref:</span>
              <strong>{orderId || "VERIFIED"}</strong>
            </div>
            <div className="receipt-row">
              <span>Date:</span>
              <strong>{new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</strong>
            </div>
            <div className="receipt-row">
              <span>Payment Status:</span>
              <strong style={{ color: "#16a34a" }}>PAID & VERIFIED ✅</strong>
            </div>

            <hr style={{ border: "none", borderTop: "1px dashed #e2e8f0", margin: "12px 0" }} />

            <div style={{ marginBottom: 12 }}>
              <span style={{ fontSize: "0.8rem", color: "#64748b", textTransform: "uppercase", fontWeight: 700, display: "block", marginBottom: 6 }}>
                Purchased Items:
              </span>
              {itemsList.map((item, idx) => (
                <div key={idx} className="receipt-row">
                  <span>{item.name || item.product?.name || "Item"} ({item.variation?.name || item.variation || "Plan"}) x {item.quantity || item.qty || 1}</span>
                  <strong>{formatCurrency(item.lineTotal || item.price)}</strong>
                </div>
              ))}
            </div>

            <div className="receipt-row" style={{ borderTop: "1.5px solid #0f172a", paddingTop: 8, fontSize: "1rem" }}>
              <strong>Total Paid</strong>
              <strong>{formatCurrency(total)}</strong>
            </div>

            <div className="receipt-warranty-box">
              <h4>🛡️ 100% Guaranteed Delivery & Warranty</h4>
              <p>
                This purchase is covered under our 100% guarantee. In case of any query or issue, instant replacement / support is provided via WhatsApp ({supportPhone}).
              </p>
            </div>

            <button type="button" className="receipt-print-btn" onClick={() => window.print()}>
              🖨️ Print / Save as PDF
            </button>
            <button
              type="button"
              className="ghost"
              style={{ width: "100%", marginTop: 8 }}
              onClick={() => setShowReceiptModal(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
export default OrderCompletedClaimScreen;
