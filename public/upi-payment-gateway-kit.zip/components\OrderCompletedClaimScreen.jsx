import FoodOrderSuccessScreen from "./FoodOrderSuccessScreen.jsx";
export { FoodOrderSuccessScreen };
export { FoodOrderSuccessScreen as OrderCompletedClaimScreen };
export default FoodOrderSuccessScreen;
